using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Portafolio.Views.Home
{
    public class Index1Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}

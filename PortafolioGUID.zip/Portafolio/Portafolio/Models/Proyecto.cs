﻿namespace Portafolio.Models
{
    public class Proyecto
    {
    }
}

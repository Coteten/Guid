﻿namespace Portafolio.Models
{
    public class HomeIndexViewModel
    {
        public IEnumerable<ProyectoViewModel> Proyectos { get; set; }
        public EjemploGUIDViewModel EjemploGUID_1 { get; set; }
    }
}

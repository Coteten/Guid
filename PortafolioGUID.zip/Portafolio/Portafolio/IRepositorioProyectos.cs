﻿internal interface IRepositorioProyectos
{
    object ObtenerProyectos();
}